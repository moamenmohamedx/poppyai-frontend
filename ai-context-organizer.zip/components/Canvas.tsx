"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Plus, ZoomIn, ZoomOut, RotateCcw, X } from "lucide-react"
import ContextLibrary from "./ContextLibrary"
import ChatCard from "./ChatCard"
import ContextCard from "./ContextCard"
import DynamicEdge from "./DynamicEdge" // Added import for DynamicEdge
import { useCanvasStore } from "@/stores/useCanvasStore"
import { useProjectStore } from "@/stores/useProjectStore"

interface CanvasProps {
  projectId: string
  onBackToDashboard: () => void
}

export default function Canvas({ projectId, onBackToDashboard }: CanvasProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [isPanning, setIsPanning] = useState(false)
  const [panStart, setPanStart] = useState({ x: 0, y: 0 })
  const [isDragOverCanvas, setIsDragOverCanvas] = useState(false)
  const canvasRef = useRef<HTMLDivElement>(null)

  const {
    chatCards,
    contextCards,
    edges, // Added edges from store
    canvasOffset,
    canvasZoom,
    addChatCard,
    setCanvasOffset,
    setCanvasZoom,
    resetCanvas,
    isConnecting,
    connectionSource,
    completeConnection: completeConnectionStore,
    cancelConnection,
  } = useCanvasStore()
  const { currentProject, addFileToProject } = useProjectStore()

  const handleCanvasClick = (e: React.MouseEvent) => {
    if (isConnecting) {
      cancelConnection()
    }
  }

  const getCardCenter = (cardId: string, cardType: "chat" | "context") => {
    const card =
      cardType === "chat" ? chatCards.find((c) => c.id === cardId) : contextCards.find((c) => c.id === cardId)

    if (!card) return { x: 0, y: 0 }

    return {
      x: card.x + card.width / 2,
      y: card.y + card.height / 2,
    }
  }

  const renderEdges = () => {
    return (
      <svg className="absolute inset-0 pointer-events-none" style={{ zIndex: 0 }}>
        {edges.map((edge) => {
          const sourceCard =
            edge.sourceType === "chat"
              ? chatCards.find((c) => c.id === edge.sourceId)
              : contextCards.find((c) => c.id === edge.sourceId)
          const targetCard =
            edge.targetType === "chat"
              ? chatCards.find((c) => c.id === edge.targetId)
              : contextCards.find((c) => c.id === edge.targetId)

          if (!sourceCard || !targetCard) return null

          // Context cards connect from right side, chat cards from left side
          const source =
            edge.sourceType === "context"
              ? { x: sourceCard.x + sourceCard.width, y: sourceCard.y + sourceCard.height / 2 }
              : { x: sourceCard.x, y: sourceCard.y + sourceCard.height / 2 }

          const target =
            edge.targetType === "chat"
              ? { x: targetCard.x, y: targetCard.y + targetCard.height / 2 }
              : { x: targetCard.x + targetCard.width, y: targetCard.y + targetCard.height / 2 }

          const dx = target.x - source.x
          const dy = target.y - source.y
          const distance = Math.sqrt(dx * dx + dy * dy)
          const controlOffset = Math.min(distance * 0.3, 100)

          const midX = (source.x + target.x) / 2
          const midY = (source.y + target.y) / 2

          const path = `M ${source.x} ${source.y} Q ${midX + (dx > 0 ? controlOffset : -controlOffset)} ${midY} ${target.x} ${target.y}`

          return (
            <g key={edge.id}>
              <path
                d={path}
                stroke="#6366f1"
                strokeWidth="2"
                fill="none"
                strokeDasharray="5,5"
                className="animate-pulse"
              />
              {/* Arrow marker */}
              <circle cx={target.x} cy={target.y} r="4" fill="#6366f1" />
            </g>
          )
        })}

        {isConnecting && connectionSource && (
          <DynamicEdge sourceId={connectionSource.id} sourceType={connectionSource.type} />
        )}
      </svg>
    )
  }

  const handleAddChatCard = () => {
    let x = (window.innerWidth / 2 - canvasOffset.x) / canvasZoom - 200
    let y = (window.innerHeight / 2 - canvasOffset.y) / canvasZoom - 140

    // Check if there are any maximized chat cards and adjust position
    const maximizedChatCards = chatCards.filter((card) => !card.isMinimized)
    if (maximizedChatCards.length > 0) {
      // Place new cards in available canvas space, not beneath maximized cards
      x = 100 + chatCards.length * 50
      y = 100 + chatCards.length * 50
    }

    const newCard = {
      id: `chat-${Date.now()}`,
      x,
      y,
      width: 400,
      height: 280,
      isMinimized: false, // Start maximized by default
      zIndex: 1,
    }
    addChatCard(newCard)
  }

  const handleZoomIn = () => {
    setCanvasZoom(Math.min(canvasZoom * 1.2, 3))
  }

  const handleZoomOut = () => {
    setCanvasZoom(Math.max(canvasZoom / 1.2, 0.1))
  }

  const handleResetView = () => {
    resetCanvas()
  }

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement
    if (
      target.closest("[data-card]") ||
      target.closest("button") ||
      target.closest("input") ||
      target.closest("textarea")
    ) {
      return
    }

    if (isConnecting) {
      cancelConnection()
      return
    }

    setIsPanning(true)
    setPanStart({
      x: e.clientX - canvasOffset.x,
      y: e.clientY - canvasOffset.y,
    })

    if (canvasRef.current) {
      canvasRef.current.style.cursor = "grabbing"
    }
  }

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isPanning) {
        const newOffset = {
          x: e.clientX - panStart.x,
          y: e.clientY - panStart.y,
        }
        setCanvasOffset(newOffset)
      }
    }

    const handleMouseUp = () => {
      setIsPanning(false)
      if (canvasRef.current) {
        canvasRef.current.style.cursor = "grab"
      }
    }

    if (isPanning) {
      document.addEventListener("mousemove", handleMouseMove)
      document.addEventListener("mouseup", handleMouseUp)
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }
  }, [isPanning, panStart, setCanvasOffset])

  const handleCanvasDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOverCanvas(true)
  }

  const handleCanvasDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    if (!canvasRef.current?.contains(e.relatedTarget as Node)) {
      setIsDragOverCanvas(false)
    }
  }

  const handleCanvasDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOverCanvas(false)

    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      files.forEach((file) => {
        const fileItem = {
          id: `file-${Date.now()}-${Math.random()}`,
          name: file.name,
          type: getFileType(file.type) as "video" | "document" | "image",
          size: formatFileSize(file.size),
          url: URL.createObjectURL(file),
          uploadedAt: new Date(),
        }
        addFileToProject(projectId, fileItem)
      })
    }
  }

  const getFileType = (mimeType: string): string => {
    if (mimeType.startsWith("video/")) return "video"
    if (mimeType.startsWith("image/")) return "image"
    return "document"
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    const rect = canvasRef.current?.getBoundingClientRect()
    if (!rect) return

    const mouseX = e.clientX - rect.left
    const mouseY = e.clientY - rect.top

    const delta = e.deltaY > 0 ? 0.9 : 1.1
    const newZoom = Math.max(0.1, Math.min(3, canvasZoom * delta))

    const zoomRatio = newZoom / canvasZoom
    const newOffsetX = mouseX - (mouseX - canvasOffset.x) * zoomRatio
    const newOffsetY = mouseY - (mouseY - canvasOffset.y) * zoomRatio

    setCanvasZoom(newZoom)
    setCanvasOffset({ x: newOffsetX, y: newOffsetY })
  }

  const completeConnection = (targetId: string, targetType: "chat" | "context") => {
    if (!connectionSource) return

    const isValidConnection =
      (connectionSource.type === "context" && targetType === "chat") ||
      (connectionSource.type === "chat" && targetType === "context")

    if (isValidConnection) {
      completeConnectionStore(targetId, targetType)
    } else {
      cancelConnection()
    }
  }

  return (
    <div className="h-screen flex bg-gray-50">
      <div className={`${sidebarCollapsed ? "w-0" : "w-80"} transition-all duration-300 overflow-hidden`}>
        <ContextLibrary
          projectId={projectId}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          isCollapsed={sidebarCollapsed}
        />
      </div>

      <div className="flex-1 relative overflow-hidden">
        <header className="bg-white border-b border-gray-200 px-6 py-4 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={onBackToDashboard} className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Dashboard</span>
              </Button>
              <h1 className="text-lg font-semibold text-gray-900">{currentProject?.name || "Untitled Project"}</h1>
            </div>
            <div className="flex items-center space-x-2">
              {isConnecting && (
                <div className="flex items-center space-x-2 bg-blue-50 border border-blue-200 rounded-lg px-3 py-1">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-blue-700">Click a card to connect</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={cancelConnection}
                    className="h-5 w-5 p-0 text-blue-500 hover:text-blue-700"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
              <span className="text-sm text-gray-600">Auto-saved</span>
            </div>
          </div>
        </header>

        <div
          ref={canvasRef}
          data-canvas
          className={`absolute inset-0 top-16 bg-gray-50 select-none transition-all duration-200 ${
            isConnecting ? "cursor-crosshair" : isPanning ? "cursor-grabbing" : "cursor-grab"
          }`}
          style={{
            backgroundImage: `radial-gradient(circle, #d1d5db 1px, transparent 1px)`,
            backgroundSize: `${20 * canvasZoom}px ${20 * canvasZoom}px`,
            backgroundPosition: `${canvasOffset.x}px ${canvasOffset.y}px`,
          }}
          onMouseDown={handleCanvasMouseDown}
          onDragOver={handleCanvasDragOver}
          onDragLeave={handleCanvasDragLeave}
          onDrop={handleCanvasDrop}
          onWheel={handleWheel}
          onClick={handleCanvasClick} // Added canvas click handler
        >
          <div
            className="absolute inset-0 origin-top-left transition-transform duration-200"
            style={{
              transform: `translate(${canvasOffset.x}px, ${canvasOffset.y}px) scale(${canvasZoom})`,
            }}
          >
            {renderEdges()}

            {chatCards.map((card) => (
              <div
                key={card.id}
                data-card
                onClick={(e) => {
                  e.stopPropagation()
                  if (isConnecting && connectionSource?.id !== card.id) {
                    completeConnection(card.id, "chat")
                  }
                }}
                onDragOver={(e) => {
                  e.preventDefault()
                  if (connectionSource?.type === "context") {
                    e.dataTransfer.dropEffect = "link"
                  }
                }}
                onDrop={(e) => {
                  e.preventDefault()
                  if (connectionSource?.type === "context" && connectionSource.id !== card.id) {
                    completeConnection(card.id, "chat")
                  }
                }}
              >
                <ChatCard card={card} projectId={projectId} />
              </div>
            ))}

            {contextCards.map((card) => (
              <div
                key={card.id}
                data-card
                onClick={(e) => {
                  e.stopPropagation()
                  if (isConnecting && connectionSource?.id !== card.id) {
                    completeConnection(card.id, "context")
                  }
                }}
                onDragOver={(e) => {
                  e.preventDefault()
                  // Only allow connections from context cards to chat cards
                  if (connectionSource?.type === "chat") {
                    e.dataTransfer.dropEffect = "link"
                  }
                }}
                onDrop={(e) => {
                  e.preventDefault()
                  // Only allow connections from chat cards to context cards
                  if (connectionSource?.type === "chat" && connectionSource.id !== card.id) {
                    completeConnection(card.id, "context")
                  }
                }}
              >
                <ContextCard card={card} projectId={projectId} />
              </div>
            ))}
          </div>

          {isDragOverCanvas && (
            <div className="absolute inset-0 bg-indigo-500 bg-opacity-10 border-4 border-dashed border-indigo-500 flex items-center justify-center z-50">
              <div className="bg-white rounded-xl p-8 shadow-lg text-center">
                <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Plus className="w-8 h-8 text-indigo-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Drop files to upload</h3>
                <p className="text-gray-600">Add videos, documents, and images to your project</p>
              </div>
            </div>
          )}
        </div>

        <div className="absolute bottom-6 right-6 flex flex-col space-y-2 z-20">
          <Button
            onClick={handleAddChatCard}
            className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-lg transition-all duration-200 hover:scale-105"
            size="lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Chat
          </Button>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleZoomIn}
              className="bg-white shadow-md rounded-lg hover:scale-105 transition-all duration-200"
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleZoomOut}
              className="bg-white shadow-md rounded-lg hover:scale-105 transition-all duration-200"
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleResetView}
              className="bg-white shadow-md rounded-lg hover:scale-105 transition-all duration-200"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
          <div className="text-xs text-gray-500 text-center bg-white px-2 py-1 rounded shadow-sm">
            Zoom: {Math.round(canvasZoom * 100)}%
          </div>
        </div>
      </div>
    </div>
  )
}
