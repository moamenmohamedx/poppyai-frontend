"use client"

import { useState, useEffect } from "react"
import { useCanvasStore } from "@/stores/useCanvasStore"

interface DynamicEdgeProps {
  sourceId: string
  sourceType: "chat" | "context"
}

export default function DynamicEdge({ sourceId, sourceType }: DynamicEdgeProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const { chatCards, contextCards, canvasOffset, canvasZoom } = useCanvasStore()

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const canvasRect = document.querySelector("[data-canvas]")?.getBoundingClientRect()
      if (!canvasRect) return

      setMousePosition({
        x: (e.clientX - canvasRect.left - canvasOffset.x) / canvasZoom,
        y: (e.clientY - canvasRect.top - canvasOffset.y) / canvasZoom,
      })
    }

    document.addEventListener("mousemove", handleMouseMove)
    return () => document.removeEventListener("mousemove", handleMouseMove)
  }, [canvasOffset, canvasZoom])

  const sourceCard =
    sourceType === "chat" ? chatCards.find((c) => c.id === sourceId) : contextCards.find((c) => c.id === sourceId)

  if (!sourceCard) return null

  const source =
    sourceType === "context"
      ? { x: sourceCard.x + sourceCard.width, y: sourceCard.y + sourceCard.height / 2 }
      : { x: sourceCard.x, y: sourceCard.y + sourceCard.height / 2 }

  const dx = mousePosition.x - source.x
  const dy = mousePosition.y - source.y
  const distance = Math.sqrt(dx * dx + dy * dy)
  const controlOffset = Math.min(distance * 0.3, 100)

  const midX = (source.x + mousePosition.x) / 2
  const midY = (source.y + mousePosition.y) / 2

  const path = `M ${source.x} ${source.y} Q ${midX + (dx > 0 ? controlOffset : -controlOffset)} ${midY} ${mousePosition.x} ${mousePosition.y}`

  return (
    <path
      d={path}
      stroke="#6366f1"
      strokeWidth="2"
      fill="none"
      strokeDasharray="5,5"
      className="animate-pulse opacity-75"
    />
  )
}
